import pygame
import random
from targetcircle import Targetcircle

# set up pygame modules
pygame.init()
pygame.font.init()
my_font = pygame.font.SysFont('Arial', 20)
my_big_font = pygame.font.SysFont('Arial', 40)
#pygame.display.set_caption("")

size = (800, 600)
screen = pygame.display.set_mode(size)
score = 0

target = Targetcircle(100, 100)
display_score = my_font.render(("Score: " + str(score)), True, (255, 0, 0))

run = True

while run:
    screen.blit(target.image, target.rect)
    pygame.display.update()

pygame.quit()