width = 1280
height = 720
FPS = 40

#player settings
player_start_x = 400
player_start_y = 500
player_speed = 8