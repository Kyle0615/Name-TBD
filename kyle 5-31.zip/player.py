import pygame
import math
from settings import *
class Player:
    def __init__(self, x, y):
        self.x = x
        print(x)
        self.y = y
        print(y)
        super().__init__()
        self.image = pygame.image.load("player.png")  # Loading player
        self.base_player_image = self.image
        self.pos = pygame.math.Vector2(player_start_x, player_start_y)
        self.speed = player_speed
        self.rect = self.image.get_rect()
        # self.rescale_image(self.image)
        self.image_size = self.image.get_size()
        self.base_player_image_size = self.base_player_image.get_size()

    def rescale_image(self, image):
        print(self.image_size)
        scale_size = self.image_size
        self.image_size = scale_size
        print(self.image_size)
        self.image_size = (self.image_size[0] * .4, self.image_size[1] * .4)

        self.hitbox_rect = pygame.Rect((self.x, self.y), (self.image_size[0], self.image_size[1]))
        self.center = ((self.x + self.image_size[0] / 2), (self.y + self.image_size[1] / 2))
        self.rect = self.hitbox_rect.copy()

    def rotate_player(self):
        self.mouse_coords = pygame.mouse.get_pos()  # Gets mouse coordinates.
        self.x_change_mouse_player_distance = (self.mouse_coords[0] - self.center[0])
        self.y_change_mouse_player_distance = (self.mouse_coords[1] - self.center[1])
        self.angle = math.degrees(math.atan2(self.y_change_mouse_player_distance, self.x_change_mouse_player_distance))
        self.image = pygame.transform.rotate(self.base_player_image, -self.angle)

        self.hitbox_rect = pygame.Rect((self.x, self.y), (self.image_size[0], self.image_size[1]))
        self.center = ((self.x + self.image_size[0] / 2), (self.y + self.image_size[1] / 2))
        self.rect = self.hitbox_rect.copy()

    def user_input(self):
        self.velocity_x = 0
        self.velocity_y = 0  # sets up speed and movement of player

        keys = pygame.key.get_pressed()

        if keys[pygame.K_w]:  # IF W KEY:
            self.velocity_y = -self.speed
        if keys[pygame.K_a]:  # IF A KEY:
            self.velocity_x = -self.speed
        if keys[pygame.K_s]:  # IF S KEY:
            self.velocity_y = self.speed
        if keys[pygame.K_d]:  # IF D KEY:
            self.velocity_x = self.speed

        if self.velocity_x != 0 and self.velocity_y != 0:  # CHECKS IF PLAYER IS GOING DIAGONALLY
            # When player moves diagonally it speeds up and instead of a velocity of 8 it has velocity of 8root2
            self.velocity_x = self.velocity_x / math.sqrt(2)  # Divide x movement and y movement by root 2 so speed is 8
            self.velocity_y = self.velocity_y / math.sqrt(2)

    def move(self):  # Moves player
        self.pos = self.pos + pygame.math.Vector2(self.velocity_x, self.velocity_y)
        self.hitbox_rect.center = self.pos
        self.rect.center = self.hitbox_rect.center

    def update(self):
        self.rescale_image(self.image)
        if self.image_size[0] < 300:
            self.image_size = self.base_player_image_size
        self.user_input()  # Updates whenever player moves
        self.move()
        self.rotate_player()

